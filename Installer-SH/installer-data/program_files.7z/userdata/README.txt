Important! If you do not have permission to modify files in this directory, the program is installed in "System" mode (/portsoft/ARCH-NAME/PROGRAM-NAME/userdata)! Check your PortSoft home directory if you need to modify configuration files (/home/USERNAME/portsoft/ARCH-NAME/PROGRAM-NAME/userdata)!

Важно! Если у вас нет прав на изменение файлов в этом каталоге, значит программа установлена в режиме «System» (/portsoft/ИМЯ_АРХИТЕКТУРЫ/ИМЯ_ПРОГРАММЫ/userdata)! Проверьте домашний каталог PortSoft, если вам нужно изменить файлы конфигурации (/home/ИМЯ_ПОЛЬЗОВАТЕЛЯ/portsoft/ИМЯ_АРХИТЕКТУРЫ/ИМЯ_ПРОГРАММЫ/userdata)!

This file was created for testing Installer-SH. This file can be deleted.
Этот файл был создан для тестирования Installer-SH. Его можно удалить.


